package com.example.productiviti_v10;

import static android.content.ContentValues.TAG;

import android.app.usage.UsageStats;
import android.content.Intent;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.icu.util.Calendar;
import android.os.Bundle;
import android.provider.Settings;
import android.util.Log;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;
import android.app.usage.UsageStatsManager;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

public class MainActivity extends AppCompatActivity {

    ListView listView;
    TextView text;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Intent intent = new Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS);
        startActivity(intent);

        // initialise layout
        listView = findViewById(R.id.listview);
        text = findViewById(R.id.totalapp);
    }

    static <K,V extends Comparable<? super V>>
    List<Map.Entry<K, V>> entriesSortedByValues(Map<K,V> map) {

        List<Map.Entry<K,V>> sortedEntries = new ArrayList<Map.Entry<K,V>>(map.entrySet());

        Collections.sort(sortedEntries,
                new Comparator<Map.Entry<K,V>>() {
                    @Override
                    public int compare(Map.Entry<K,V> e1, Map.Entry<K,V> e2) {
                        return e2.getValue().compareTo(e1.getValue());
                    }
                }
        );

        return sortedEntries;
    }
    public void getallapps(View view) {

        UsageStatsManager statsManager = (UsageStatsManager) getSystemService(USAGE_STATS_SERVICE);
        long endtime = System.currentTimeMillis();
        long starttime = endtime - (100000000);
        Calendar beginCal = Calendar.getInstance();
        beginCal.set(Calendar.DATE, 1);
        beginCal.set(Calendar.MONTH, 1);
        beginCal.set(Calendar.YEAR, 2022);

        Calendar endCal = Calendar.getInstance();
        endCal.set(Calendar.DATE, 13);
        endCal.set(Calendar.MONTH, 6);
        endCal.set(Calendar.YEAR, 2022);


        List<UsageStats> statsUsagelist = statsManager.queryUsageStats(UsageStatsManager.INTERVAL_BEST, beginCal.getTimeInMillis(), endCal.getTimeInMillis());
        String[] lis = new String[statsUsagelist.size()];


        HashMap<String, Long> valueMap = new HashMap<String,Long>();
        int j = 0;
        if(statsUsagelist !=null){
            for(UsageStats usageStats:statsUsagelist){
                //Log.d(TAG, "getallapps: "+usageStats.getPackageName() + " " + j);
                lis[j] = usageStats.getPackageName() + " " + usageStats.getTotalTimeInForeground();
                valueMap.put(usageStats.getPackageName(),usageStats.getTotalTimeInForeground());
                j++;
            }

        }

        long l = 0;
        valueMap.entrySet()
                .removeIf(
                        entry -> (l==entry.getValue()));

        List<Map.Entry<String, Long>> hm1 = entriesSortedByValues(valueMap);
        j = 0;
        String[] lis2 = new String[hm1.size()];
        while(j < hm1.size()){
            lis2[j] = String.valueOf(hm1.get(j));
            j++;
        }
        listView.setAdapter(new ArrayAdapter<String>(MainActivity.this, android.R.layout.simple_list_item_1, lis2));
        Log.d(TAG, "getallapps: statsUsagelist " +hm1.get(1));


        // get list of all the apps installed
        List<ApplicationInfo> infos = getPackageManager().getInstalledApplications(PackageManager.GET_META_DATA);
        // create a list with size of total number of apps
        String[] apps = new String[infos.size()];
        int i = 0;
        // add all the app name in string list
        for (ApplicationInfo info : infos) {
            apps[i] = info.packageName;
            i++;
        }



        // set all the apps name in list view
        //listView.setAdapter(new ArrayAdapter<String>(MainActivity.this, android.R.layout.simple_list_item_1, apps));
        // write total count of apps available.
        text.setText(infos.size() + " Apps are installed");

    }

    @Override
    protected void onStart() {
        super.onStart();

    }
}